const questions = [
  {
    question: "What type of battery is commonly used in laptops?",
    options: ["Nickel-Cadmium", "Lithium-Ion", "Alkaline", "Lead-Acid"],
    answer: "Lithium-Ion",
    category: "1.1"
  },
  {
    question: "Which module type is commonly used in laptops for memory?",
    options: ["DIMM", "SO-DIMM", "RIMM", "SIMM"],
    answer: "SO-DIMM",
    category: "1.2"
  }
];
